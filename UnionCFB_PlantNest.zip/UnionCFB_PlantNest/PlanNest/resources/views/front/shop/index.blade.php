
@extends('front.layout.master1')

@section('title', 'Plants')
@section('content')
    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(front/img/bg-img/24.jpg);">
            <h2>Plants</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Plants</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### Shop Area Start ##### -->
    <section class="shop-page section-padding-0-100">
        <div class="container">


            <div class="row">
                <!-- Shop Sorting Data -->
                <div class="col-12">
                    <div class="shop-sorting-data d-flex flex-wrap align-items-center justify-content-between">
                        <!-- Shop Page Count -->
                        <div class="shop-page-count">
{{--                            <p>Showing 1–9 of 72 results</p>--}}
                        </div>
                        <!-- Search by Terms -->
                        <div class="search_by_terms">

                            <form action="{{ request()->segment(2) == 'product' ? 'shop' : '' }}" class="form-inline">
                                <select class="custom-select widget-title"  name="sort_by" onchange="this.form.submit();">
                                    <option {{ request('sort_by') == 'latest' ? 'selected' : '' }} value="latest">Sorting: Latest</option>
                                    <option {{ request('sort_by') == 'oldest' ? 'selected' : '' }} value="oldest">Sorting: Oldest</option>
                                    <option {{ request('sort_by') == 'name-ascending' ? 'selected' : '' }} value="name-ascending">Sorting: Name A-Z</option>
                                    <option {{ request('sort_by') == 'name-descending' ? 'selected' : '' }} value="name-descending">Sorting: Name Z-A</option>
                                    <option {{ request('sort_by') == 'price-ascending' ? 'selected' : '' }} value="price-ascending">Sorting: Price Ascending</option>
                                    <option {{ request('sort_by') == 'price-descending' ? 'selected' : '' }} value="price-descending">Sorting: Price Descending</option>
                                </select>
                                <select class="custom-select widget-title" name="show" onchange="this.form.submit();">
                                    <option {{ request('show') == '3' ? 'selected' : '' }} value="3">Show: 6</option>
                                    <option {{ request('show') == '9' ? 'selected' : '' }} value="9">Show: 9</option>
                                    <option {{ request('show') == '15' ? 'selected' : '' }} value="15">Show: 15</option>
                                </select>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <form action="{{ request()->segment(2) == 'product' ? 'shop' : '' }}" class="form-inline">

            <div class="row">
                <!-- Sidebar Area -->
                <div class="col-12 col-md-4 col-lg-3">
                    <div class="shop-sidebar-area">
                        <!-- Shop Widget -->
                        <div class="filter-widget">
                            <h4 class="fw-title">Price</h4>
                            <div class="filter-range-wrap">
                                <div class="range-slider">
                                    <div class="price-input">
                                        <input type="text" id="minamount" name="price_min">
                                        <input type="text" id="maxamount" name="price_max">

                                    </div>
                                </div>
                                <div class="price-range ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content"
                                     data-min="2"  data-max ="999"
                                     data-min-value="{{ str_replace('$', '', request('price_min')) }}"
                                     data-max-value="{{ str_replace('$', '', request('price_max')) }}">
                                    <div class="ui-slider-range ui-corner-all ui-widget-header">

                                    </div>
                                    <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                                    <span tabindex="0" class="ui-slider-handle ui-corner-all ui-state-default"></span>
                                </div>
                            </div>
                            <button type="submit" class="filter-btn">Filter</button>
                        </div>

                        <!-- Shop Widget -->
                        <div class="shop-widget catagory mb-50">
                            <h4 class="widget-title">Categories</h4>
                            <div class="widget-desc">

                                        <ul class="filter-catagories">
                                            @foreach($categories as $category)
                                                <li><a class="widget-title-item" href="shop/{{ $category->name }}">{{ $category->name }}</a></li>
                                            @endforeach

                                        </ul>
                            </div>
                        </div>

                        <!-- Shop Widget -->

                        <!-- Shop Widget -->
                    </div>
                </div>



                <!-- All Products Area -->
                <div class="col-12 col-md-8 col-lg-9">
                    <div class="shop-products-area">
                        <div class="row">

                            @foreach($products as $product)
                                <!-- Single Product Area -->
                                <div class="col-12 col-sm-6 col-lg-4">
                                    <div class="single-product-area mb-50">
                                        <!-- Product Image -->
                                        <div class="product-img1">
                                            <a href="./shop/product/{{ $product->id }}"><img src="front/img/products/{{$product->productImages[0]->path}}" alt=""></a>
                                            <!-- Product Tag -->
{{--                                            <div class="product-tag">--}}
{{--                                                <a href="#">Hot</a>--}}
{{--                                            </div>--}}
                                            <div class="product-meta d-flex">
                                                <a href="#" class="wishlist-btn"><i class="icon_heart_alt"></i></a>
                                                <a href="./cart/add/{{ $product->id }}" class="add-to-cart-btn">Add to cart</a>
                                                <a href="#" class="compare-btn"><i class="arrow_left-right_alt"></i></a>
                                            </div>
                                        </div>
                                        <!-- Product Info -->
                                        <div class="product-info mt-15 text-center">
                                            <a href="./shop/product/{{ $product->id }}">
                                                <p>{{ $product->name }}</p>
                                            </a>
                                            <h6>${{ $product->price }}</h6>
                                        </div>
                                    </div>
                                </div>
                            @endforeach


                        </div>

                        <!-- Pagination -->
                        <nav aria-label="Page navigation">
                            {{ $products->links() }}
                        </nav>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </section>
    <!-- ##### Shop Area End ##### -->


@endsection

