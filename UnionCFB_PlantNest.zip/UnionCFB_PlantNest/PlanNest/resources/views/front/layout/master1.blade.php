<!DOCTYPE html>
<html lang="en">

<head>
    <base href="{{ asset('/') }}">
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>PlantNest | @yield('title')</title>

    <!-- Favicon -->
    <link rel="icon" href="./front/img/core-img/favicon.ico">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">


    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="./front/css/style.css">

</head>

<body>
<!-- Preloader -->
<div class="preloader d-flex align-items-center justify-content-center">
    <div class="preloader-circle"></div>
    <div class="preloader-img">
        <img src="./front/img/core-img/leaf.png" alt="">
    </div>
</div>

<!-- ##### Header Area Start ##### -->
<header class="header-area">

    <!-- ***** Top Header Area ***** -->
    <div class="top-header-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="top-header-content d-flex align-items-center justify-content-between">
                        <!-- Top Header Content -->
                        <div class="top-header-meta">
                            <a href="mailto:plantnest.company@gmail.com" data-toggle="tooltip" data-placement="bottom" title="plantnest.company@gmail.com"><i class="fa fa-envelope-o" aria-hidden="true"></i> <span>Email: plantnest.company@gmail.com</span></a>
                            <a href="tel:+1 234 122 122" data-toggle="tooltip" data-placement="bottom" title="+1 234 122 122"><i class="fa fa-phone" aria-hidden="true"></i> <span>Call Us: +1 234 122 122</span></a>
                        </div>

                        <!-- Top Header Content -->
                        <div class="top-header-meta d-flex">
                            <!-- Language Dropdown -->

                            <!-- Login -->
                            <!-- Login -->
                            <div class="login">
                                @if(Auth::check())
                                    <ul>


                                        <li>
                                            <a href="account/information" >
                                                <i class="fa fa-user"></i>
                                                {{ Auth::user()->name }}
                                            </a>
                                        </li>
                                    </ul>

                                @else
                                    <a href="account/login"><i class="fa fa-user" aria-hidden="true"></i> <span>Login</span></a>
                                @endif
                            </div>
                            <!-- Cart -->
                            <div class="cart">
                                <a href="./cart"><i class="fa fa-shopping-cart" aria-hidden="true"></i> <span>Cart <span class="cart-quantity">({{ Cart::count()}})</span></span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- ***** Navbar Area ***** -->
    <div class="alazea-main-menu">
        <div class="classy-nav-container breakpoint-off">
            <div class="container">
                <!-- Menu -->
                <nav class="classy-navbar justify-content-between" id="alazeaNav">

                    <!-- Nav Brand -->
                    <a href="./" class="nav-brand"><img src="./front/img/core-img/logo.png" alt=""></a>

                    <!-- Navbar Toggler -->
                    <div class="classy-navbar-toggler">
                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>

                    <!-- Menu -->
                    <div class="classy-menu">

                        <!-- Close Button -->
                        <div class="classycloseIcon">
                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                        </div>

                        <!-- Navbar Start -->
                        <div class="classynav">
                            <ul>
                                <li><a class="{{ request()->segment(1) == '' ? 'active-nav-1' : '' }}" href="./">Home</a></li>

                                <li><a href="#" class="{{ request()->segment(1) == 'aboutus'  ? 'active-nav-1' : '' }} {{ request()->segment(1) == 'blogs'  ? 'active-nav-1' : '' }}">Pages</a>
                                    <ul class="dropdown">
                                        <li><a href="./aboutus">About</a></li>
                                        <li><a href="./blogs">Blogs</a></li>

                                    </ul>
                                </li>
                                <li><a class="{{ request()->segment(1) == 'shop' ? 'active-nav-1' : '' }}" href="./shop">Plants</a></li>
                                <li><a  href="./shop/Accessories">Accessories</a></li>
                                <li><a class="{{ request()->segment(1) == 'contactus' ? 'active-nav-1' : '' }}" href="./contactus">Contact</a></li>
                                @if(Auth::check())
                                    <li><a class="{{ request()->segment(1) == 'my-order' ? 'active-nav-1' : '' }}" href="./account/my-order">My Order</a></li>
                                @endif
                            </ul>

                            <!-- Search Icon -->
                            <div id="searchIcon">
                                <i class="fa fa-search" aria-hidden="true"></i>
                            </div>

                        </div>
                        <!-- Navbar End -->
                    </div>
                </nav>

                <!-- Search Form -->
                <div class="search-form">
                    <form action="shop" method="get">
                        <input type="search" name="search" id="search" placeholder="Type keywords &amp; press enter...">
                        <button type="submit" class="d-none"></button>
                    </form>
                    <!-- Close Icon -->
                    <div class="closeIcon"><i class="fa fa-times" aria-hidden="true"></i></div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- ##### Header Area End ##### -->




@yield('content')


<!-- ##### Footer Area Start ##### -->
<footer class="footer-area bg-img" style="background-image: url({{url('/front/img/bg-img/3.jpg')}});">

    <!-- Main Footer Area -->
    <div class="main-footer-area">
        <div class="container">
            <div class="row">

                <!-- Single Footer Widget -->
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="single-footer-widget">
                        <div class="footer-logo mb-30">
                            <a href="#"><img src="./front/img/core-img/logo.png" alt=""></a>
                        </div>
                        <p>Our stores around the US are open for plant shopping, repotting, curbside pickup, in-person workshops, and more.</p>
                        <div class="social-info">
                            <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Single Footer Widget -->
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="single-footer-widget">
                        <div class="widget-title">
                            <h5>QUICK LINK</h5>
                        </div>
                        <nav class="widget-nav">
                            <ul>
                                <li><a href="#">Purchase</a></li>
                                <li><a href="#">FAQs</a></li>
                                <li><a href="#">Payment</a></li>
                                <li><a href="#">News</a></li>
                                <li><a href="#">Return</a></li>
                                <li><a href="#">Advertise</a></li>
                                <li><a href="#">Shipping</a></li>
                                <li><a href="#">Career</a></li>
                                <li><a href="#">Orders</a></li>
                                <li><a href="#">Policities</a></li>
                            </ul>
                        </nav>
                    </div>
                </div>

                <!-- Single Footer Widget -->


                <!-- Single Footer Widget -->
                <div class="col-12 col-sm-6 col-lg-3">
                    <div class="single-footer-widget">
                        <div class="widget-title">
                            <h5>CONTACT</h5>
                        </div>

                        <div class="contact-information">
                            <p><span>Address:</span> 505 Silk Rd, New York</p>
                            <p><span>Phone:</span> +1 234 122 122</p>
                            <p><span>Email:</span> plantnest.company@gmail.com</p>
                            <p><span>Open hours:</span> Mon - Sun: 8 AM to 9 PM</p>
                            <p><span>Happy hours:</span> Sat: 2 PM to 4 PM</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Bottom Area -->
    <div class="footer-bottom-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="border-line"></div>
                </div>
                <!-- Copywrite Text -->
                <div class="col-12">
                    <div class="copywrite-text">
                        <p>&copy; <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#" target="_blank">Union CFB</a>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                </div>
                <!-- Footer Nav -->

            </div>
        </div>
    </div>
</footer>
<!-- ##### Footer Area End ##### -->

<!-- ##### All Javascript Files ##### -->
<!-- jQuery-2.2.4 js -->

<script src="./front/js/jquery/jquery-2.2.4.min.js"></script>
<!-- Popper js -->
<script src="./front/js/bootstrap/popper.min.js"></script>
<!-- Bootstrap js -->
<script src="./front/js/bootstrap/bootstrap.min.js"></script>
<!-- All Plugins js -->
<script src="./front/js/plugins/plugins.js"></script>
<!-- Active js -->
<script src="./front/js/active.js"></script>
<script src="./front/js/jquery/jquery-ui.min.js"></script>
<script src="./front/js/main.js"></script>




</body>

</html>
