@extends('front.layout.master1')
@section('title', 'Blogs')
@section('content')


    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(front/img/bg-img/24.jpg);">
            <h2>BLOG DEFAULT</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/"><i class="fa fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Blog</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### Blog Area Start ##### -->
    <section class="alazea-blog-area mb-100">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-8">
                    <div class="row">

                      @foreach($blogs as $blog)
                            <!-- Single Blog Post Area -->
                            <div class="col-12 col-lg-6">
                                <div class="single-blog-post mb-50">
                                    <div class="post-thumbnail mb-30">
                                        <a href="./blogs/{{ $blog->id }}"><img src="front/img/blog/{{ $blog->image }}" alt=""></a>
                                    </div>
                                    <div class="post-content">
                                        <a href="./blogs/{{ $blog->id }}" class="post-title">
                                            <h5>{{ $blog->title }}</h5>
                                        </a>
                                        <div class="post-meta">
                                            <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i> {{ date('M, d, Y,', strtotime($blog->created_at)) }}</a>
                                            <a href="#"><i class="fa fa-user" aria-hidden="true"></i> {{ $blog->author }}</a>
                                        </div>
                                        <p class="post-excerpt">{{ $blog->description }}</p>
                                    </div>
                                </div>
                            </div>

                        @endforeach

                    </div>

                    <div class="row">
                        <div class="col-12">
                            <nav aria-label="Page navigation">
                                {{ $blogs->links() }}
                            </nav>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-4">
                    <div class="post-sidebar-area">

                        <div class="single-widget-area">
                            <form action="/blogs"  class="search-form">

                                <input type="search" name="search" id="widgetsearch" placeholder="Search...">
                                <button type="submit"><i class="icon_search"></i></button>
                            </form>
                        </div>
                        <!-- ##### Single Widget Area ##### -->
                        <div class="single-widget-area">
                            <!-- Title -->
                            <div class="widget-title">
                                <h4>Recent post</h4>
                            </div>

                            @foreach($blog2 as $blog1)
                                <!-- Single Latest Posts -->
                                <div class="single-latest-post d-flex align-items-center">
                                    <div class="post-thumb">
                                        <img src="front/img/blog/{{$blog1->image}}" alt="">
                                    </div>
                                    <div class="post-content">
                                        <a href="./blogs/{{$blog1->id}}" class="post-title">
                                            <h6>{{$blog1->title}}</h6>
                                        </a>
                                        <a href="#" class="post-date">{{ date('M, d, Y,', strtotime($blog1->created_at)) }}</a>
                                    </div>
                                </div>
                            @endforeach



                        </div>



                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Blog Area End ##### -->

@endsection
