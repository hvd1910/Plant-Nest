
@extends('front.layout.master1')

@section('title', 'My Order')
@section('content')

    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(front/img/bg-img/24.jpg);">
            <h2>My Order</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">login</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>



    <!--Shopping Cart Section Begin-->
    <div class="shopping-cart spad">
        <div class="container">
            @include('admin.components.notiification')
            <div class="row">

                <div class="col-lg-12">
                    <div class="cart-table">
                        <table>
                            <thead>
                            <tr>
                                <th>Image</th>
                                <th>ID</th>
                                <th class="p-name">Product Name</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Details</th>
                            </tr>
                            </thead>
                            <tbody>

                            @foreach($orders as $order)
                                <tr>
                                    <td  class="cart-pic first-row"><img style="height: 170px" src="front/img/products/{{ $order->orderDetails[0]->product->productImages[0]->path }}" alt=""></td>
                                    <td class="first-row">{{ $order->id }}</td>
                                    <td class="cart-title first-row">
                                        <h5>
                                            {{ $order->orderDetails[0]->product->name }}
                                            @if(count($order->orderDetails ) >1)
                                                (and {{ count($order->orderDetails )}}  orther products)
                                            @endif
                                        </h5>
                                    </td>
                                    <td class="total-price first-row">
                                        ${{ array_sum(array_column($order->orderDetails->toArray(), 'total')) }}
                                    </td>

                                    <td class="status first-row ">
                                        <p class="badge badge-dark">{{ \App\Utilities\Constant::$order_status[$order->status] }}</p>
                                    </td>

                                    <td class="first-row">
                                        <a href="./account/my-order/show/{{ $order->id }}" class="btn">Details</a>
                                       @if($order->status == 2)
                                            <form action="./account/my-order/{{ $order->id }}" method="post">
                                                @csrf

                                                <input type="hidden" name="id" value="{{ $order->id }}">
                                                <input type="hidden" name="status" value="0">
                                                <button  type="submit" class="btn">Cancel Order</button>
                                            </form>
                                       @endif
                                    </td>
                                </tr>
                            @endforeach

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--Shopping Cart Section End-->





@endsection

