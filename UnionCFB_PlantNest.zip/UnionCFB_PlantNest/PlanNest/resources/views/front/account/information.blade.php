@extends('front.layout.master1')

@section('title', 'Info User')
@section('content')


    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(front/img/bg-img/24.jpg);">
            <h2>Information</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Information</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>


    <!--    Information Sectiom Begin-->
    <div class="register-login-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3">
                    <div class="register-form">
                        <h2>Information</h2>

                       @include('admin.components.notiification')

                        @if (Auth::check())

                            <form action="" method="post" >

                                @csrf

                                <input type="hidden" id="id" name="id" placeholder="id" value="{{Auth::user()->id}}">

                                <div class="group-input">
                                    <label for="name">Name *</label>
                                    <input type="name" id="name" name="name" placeholder="Name" value="{{Auth::user()->name}}">
                                </div>

                                <div class="group-input">
                                    <label for="email">email  *</label>
                                    <input type="email" id="email" name="email" placeholder="Email" value="{{Auth::user()->email}}">
                                </div>


                                <div class="group-input">
                                    <label for="password">Password *</label>
                                    <input type="password" id="password" name="password" placeholder="Password" required>
                                </div>

                                <div class="group-input">
                                    <label for="description">Description *</label>
                                    <input type="text" id="description" name="description" placeholder="Descripion" value="{{Auth::user()->description}}">
                                </div>

                                <div class="group-input">
                                    <label for="company_name">Company Name  *</label>
                                    <input type="text" id="company_name" name="company_name" placeholder="Company Name" value="{{Auth::user()->company_name}}">
                                </div>

                                <div class="group-input">
                                    <label for="country">Country  *</label>
                                    <input type="text" id="country" name="country" placeholder="Country" value="{{Auth::user()->country}}">
                                </div>

                                <div class="group-input">
                                    <label for="street_address">Address  *</label>
                                    <input type="text" id="street_address" name="street_address" placeholder="Address" value="{{Auth::user()->street_address}}">
                                </div>

                                <div class="group-input">
                                    <label for="postcode_zip  ">Postcode  *</label>
                                    <input type="text" id="postcode" name="postcode_zip" placeholder="Postcode" value="{{Auth::user()->postcode_zip}}">
                                </div>

                                <div class="group-input">
                                    <label for="town_city">Town City  *</label>
                                    <input type="text" id="town_city" name="town_city" placeholder="Town City" value="{{Auth::user()->town_city}}">
                                </div>

                                <div class="group-input">
                                    <label for="phone">Phone  *</label>
                                    <input type="phone" id="phone" name="phone" placeholder="Phone" value="{{Auth::user()->phone}}">
                                </div>

                                <button type="submit" class="site-btn register-btn">UPDATE</button>

                                <button  class="site-btn register-btn" >
                                    <a href="account/logout" class="btn-logout">
                                        LOGOUT
                                    </a>
                                </button>
                            </form>

                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>



@endsection
