@if(session('notification'))
    <div class="alert alert-warning" role="alert">
        {{ session('notification') }}
    </div>
@endif


@if(session('success'))
    <div class="alert alert-success" role="alert">
        {{ session('success') }}
    </div>
@endif
