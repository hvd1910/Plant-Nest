<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Front\Homecontroller;
use \App\Models\User;
use App\Http\Controllers\Front;
use App\Http\Controllers\Admin;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [Front\HomeController::class,'index']);


Route::get('/aboutus', [Front\HomeController::class,'aboutus']);
Route::get('/blogs', [Front\HomeController::class,'blog']);


Route::resource('blogs', Front\BlogController::class);




Route::prefix('contactus')->group(function () {
    Route::get('/', [Front\ContactusController::class,'index']);
    Route::post('/', [Front\ContactusController::class,'postContactus']);

});


Route::prefix('shop')->group(function () {
    Route::get('/product/{id}', [Front\ShopController::class, 'show']);
    Route::post('/product/{id}', [Front\ShopController::class, 'postComment']);
    Route::get('/', [Front\ShopController::class, 'index']);
    Route::get('/{categoryName}', [Front\ShopController::class,'category']);
});


Route::prefix('checkout')->group(function () {
    Route::get('/', [Front\CheckOutController::class, 'index']);
    Route::post('/', [Front\CheckOutController::class, 'addOrder']);
    Route::get('/vnPayCheck', [Front\CheckOutController::class, 'vnPayCheck']);
    Route::get('/result', [Front\CheckOutController::class, 'result']);

});



Route::prefix('cart')->group(function () {
    Route::get('add/{id}', [Front\CartController::class, 'add']);
    Route::get('/', [Front\CartController::class, 'index']);
    Route::get('delete/{rowId}', [Front\CartController::class, 'delete']);
    Route::get('destroy', [Front\CartController::class, 'destroy']);
    Route::get('update', [Front\CartController::class, 'update']);


});



// Admin
Route::prefix('admin')->middleware('CheckAdminLogin')->group(function () {
    Route::redirect('', 'admin/home');

    Route::resource('user', Admin\UserController::class);
    Route::resource('category', Admin\ProductCategoryController::class);
    Route::resource('product/{product_id}/image', Admin\ProductImageController::class);
    Route::resource('product', Admin\ProductController::class);
    Route::resource('order', Admin\OrderController::class);
    Route::resource('contactus', Admin\ContactusController::class);
    Route::resource('blogs', Admin\BlogController::class);



    Route::get('home', [Admin\DashController::class, 'index']);



    Route::prefix('login')->group(function () {
        Route::get('', [Admin\HomeController::class, 'getLogin'])->withoutMiddleware('CheckAdminLogin');
        Route::post('', [Admin\HomeController::class, 'postLogin'])->withoutMiddleware('CheckAdminLogin');
    });
    Route::get('logout', [Admin\HomeController::class, 'logout']);
});


Route::prefix('account')->group(function(){
    Route::get('login', [App\Http\Controllers\Front\AccountController::class, 'login']);
    Route::post('login', [App\Http\Controllers\Front\AccountController::class, 'checkLogin']);

    Route::get('logout', [App\Http\Controllers\Front\AccountController::class, 'logout']);

    Route::get('register', [App\Http\Controllers\Front\AccountController::class, 'register']);

    Route::post('register', [App\Http\Controllers\Front\AccountController::class, 'postRegister']);

    Route::get('information', [App\Http\Controllers\Front\AccountController::class, 'information']);

    Route::post('information', [App\Http\Controllers\Front\AccountController::class, 'postInformation']);

    Route::prefix('my-order')->middleware('CheckMemberLogin')->group(function () {
        Route::get('/', [Front\AccountController::class, 'myOrderIndex']);
        Route::post('/{id}', [Front\AccountController::class, 'cancelorder']);
        Route::get('/show/{id}', [Front\AccountController::class, 'myOrderShow']);

    });

});


