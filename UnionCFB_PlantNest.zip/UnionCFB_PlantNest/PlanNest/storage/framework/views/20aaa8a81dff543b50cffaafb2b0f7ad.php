
<section class="testimonial-area section-padding-100 chart1">
    <div class="container container-chart1">
        <div class="row">
            <div class="col-12">
                <canvas width="1200px" height="500px" id="myChart"></canvas>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <canvas width="1200px" height="500px" id="mybar"></canvas>
            </div>
        </div>

    </div>
</section>

    <input type="hidden" value="<?php echo e($orders_v2); ?>" id="orders_v2">

    <input type="hidden" value="<?php echo e($times_arr); ?>" id="times_arr">

    <input type="hidden" value="<?php echo e($totals_all); ?>" id="totals_v2">








<?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/admin/dash/chart.blade.php ENDPATH**/ ?>