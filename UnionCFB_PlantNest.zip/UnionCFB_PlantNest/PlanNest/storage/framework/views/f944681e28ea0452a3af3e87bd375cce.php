<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Main -->
            <div class="app-main__inner">
                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-ticket icon-gradient bg-mean-fruit"></i>
                            </div>
                            <div>
                                Blogs
                                <div class="page-title-subheading">
                                    View, create, update, delete and manage.
                                </div>
                            </div>
                        </div>

                    </div>
                </div>



                <ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
                    <li class="nav-item">
                        <a href="./admin/blogs/<?php echo e($blog->id); ?>/edit" class="nav-link">
                                <span class="btn-icon-wrapper pr-2 opacity-8">
                                    <i class="fa fa-edit fa-w-20"></i>
                                </span>
                            <span>Edit</span>
                        </a>
                    </li>

                    <li class="nav-item delete">
                        <form action="./admin/blogs/<?php echo e($blog->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="nav-link btn" type="submit"
                                    onclick="return confirm('Do you really want to delete this item?')">
                                    <span class="btn-icon-wrapper pr-2 opacity-8">
                                        <i class="fa fa-trash fa-w-20"></i>
                                    </span>
                                <span>Delete</span>
                            </button>
                        </form>
                    </li>
                </ul>

                <?php echo $__env->make('admin.components.notiification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="row">
                    <div class="col-md-12">
                        <div class="main-card mb-3 card">
                            <div class="card-body display_data">
                                <div class="position-relative row form-group">
                                    <label for="image" class="col-md-3 text-md-right col-form-label">Image</label>
                                    <div class="col-md-9 col-xl-8">
                                        <p>
                                            <img style="height: 200px;" class="" data-toggle="tooltip"
                                                 title="Avatar" data-placement="bottom"
                                                 src="<?php if(isset($blog->image)): ?>front/img/blog/<?php echo e($blog->image); ?>

                                            <?php else: ?>
                                                dashboard/assets/images/_default-user.png
                                            <?php endif; ?>
                                                 " alt="Avatar">
                                        </p>
                                    </div>
                                </div>

                                <div class="position-relative row form-group">
                                    <label for="title" class="col-md-3 text-md-right col-form-label">
                                        Title
                                    </label>
                                    <div class="col-md-9 col-xl-8">
                                        <p><?php echo e($blog->title); ?></p>
                                    </div>
                                </div>



                                <div class="position-relative row form-group">
                                    <label for="author" class="col-md-3 text-md-right col-form-label">
                                        Author
                                    </label>
                                    <div class="col-md-9 col-xl-8">
                                        <p><?php echo e($blog->author); ?></p>
                                    </div>
                                </div>

                                <div class="position-relative row form-group">
                                    <label for="author_introduction"
                                           class="col-md-3 text-md-right col-form-label">Introduction</label>
                                    <div class="col-md-9 col-xl-8">
                                        <p><?php echo e($blog->author_introduction); ?></p>
                                    </div>
                                </div>
                                <div class="position-relative row form-group">
                                    <label for="description"
                                           class="col-md-3 text-md-right col-form-label">Description</label>
                                    <div class="col-md-9 col-xl-8">
                                        <p><?php echo e($blog->description); ?></p>
                                    </div>
                                </div>

                                <div class="position-relative row form-group">
                                    <label for="content"
                                           class="col-md-3 text-md-right col-form-label">Content</label>
                                    <div class="col-md-9 col-xl-8">
                                        <p><?php echo $blog->content; ?> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/admin/blog/show.blade.php ENDPATH**/ ?>