<?php $__env->startSection('title', 'My Order'); ?>
<?php $__env->startSection('content'); ?>

    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(front/img/bg-img/24.jpg);">
            <h2>My Order</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">login</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>



    <!--Shopping Cart Section Begin-->
    <div class="shopping-cart spad">
        <div class="container">
            <?php echo $__env->make('admin.components.notiification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">

                <div class="col-lg-12">
                    <div class="cart-table">
                        <table>
                            <thead>
                            <tr>
                                <th>Image</th>
                                <th>ID</th>
                                <th class="p-name">Product Name</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Details</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td  class="cart-pic first-row"><img style="height: 170px" src="front/img/products/<?php echo e($order->orderDetails[0]->product->productImages[0]->path); ?>" alt=""></td>
                                    <td class="first-row"><?php echo e($order->id); ?></td>
                                    <td class="cart-title first-row">
                                        <h5>
                                            <?php echo e($order->orderDetails[0]->product->name); ?>

                                            <?php if(count($order->orderDetails ) >1): ?>
                                                (and <?php echo e(count($order->orderDetails )); ?>  orther products)
                                            <?php endif; ?>
                                        </h5>
                                    </td>
                                    <td class="total-price first-row">
                                        $<?php echo e(array_sum(array_column($order->orderDetails->toArray(), 'total'))); ?>

                                    </td>

                                    <td class="status first-row ">
                                        <p class="badge badge-dark"><?php echo e(\App\Utilities\Constant::$order_status[$order->status]); ?></p>
                                    </td>

                                    <td class="first-row">
                                        <a href="./account/my-order/show/<?php echo e($order->id); ?>" class="btn">Details</a>
                                       <?php if($order->status == 2): ?>
                                            <form action="./account/my-order/<?php echo e($order->id); ?>" method="post">
                                                <?php echo csrf_field(); ?>

                                                <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                                                <input type="hidden" name="status" value="0">
                                                <button  type="submit" class="btn">Cancel Order</button>
                                            </form>
                                       <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!--Shopping Cart Section End-->





<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/front/account/my-order/index.blade.php ENDPATH**/ ?>