<?php $__env->startSection('title', 'Edit'); ?>

<?php $__env->startSection('content'); ?>


            <!-- Main -->
            <div class="app-main__inner">

                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-ticket icon-gradient bg-mean-fruit"></i>
                            </div>
                            <div>
                                Order
                                <div class="page-title-subheading">
                                    View, create, update, delete and manage.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="main-card mb-3 card">
                            <div class="card-body">
                                <form method="post" action="/admin/order/<?php echo e($order -> id); ?>" enctype="multipart/form-data">

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <?php echo $__env->make('admin.components.notiification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo e($order->user_id); ?>">
                                    <div class="position-relative row form-group">
                                        <label for="first_name" class="col-md-3 text-md-right col-form-label">First Name</label>
                                        <div class="col-md-9 col-xl-3">
                                            <input required name="first_name" id="first_name" placeholder="First Name" type="text"
                                                   class="form-control" value="<?php echo e($order->first_name); ?>">
                                        </div>
                                        <label for="last_name" class="boa1 col-md-3 text-md-right col-form-label">Last Name</label>
                                        <div class="col-md-9 col-xl-3 boa2" >
                                            <input required name="last_name" id="last_name" placeholder="Last Name" type="text"
                                                   class="form-control" value="<?php echo e($order->last_name); ?>">
                                        </div>
                                    </div>

                                    <div class="position-relative row form-group">

                                    </div>

                                    <div class="position-relative row form-group">
                                        <label for="email"
                                               class="col-md-3 text-md-right col-form-label">Email</label>
                                        <div class="col-md-9 col-xl-8">
                                            <input required name="email" id="email" placeholder="Email" type="email"
                                                   class="form-control" value="<?php echo e($order->email); ?>">
                                        </div>
                                    </div>


                                    <div class="position-relative row form-group">
                                        <label for="company_name" class="col-md-3 text-md-right col-form-label">
                                            Company Name
                                        </label>
                                        <div class="col-md-9 col-xl-8">
                                            <input name="company_name" id="company_name"
                                                   placeholder="Company Name" type="text" class="form-control"
                                                   value="<?php echo e($order->company_name); ?>">
                                        </div>
                                    </div>

                                    <div class="position-relative row form-group">
                                        <label for="country"
                                               class="col-md-3 text-md-right col-form-label">Country</label>
                                        <div class="col-md-9 col-xl-8">
                                            <input name="country" id="country" placeholder="Country"
                                                   type="text" class="form-control" value="<?php echo e($order->country); ?>">
                                        </div>
                                    </div>

                                    <div class="position-relative row form-group">
                                        <label for="street_address" class="col-md-3 text-md-right col-form-label">
                                            Street Address
                                        </label>
                                        <div class="col-md-9 col-xl-8">
                                            <input name="street_address" id="street_address"
                                                   placeholder="Street Address" type="text" class="form-control"
                                                   value="<?php echo e($order->street_address); ?>">
                                        </div>
                                    </div>

                                    <div class="position-relative row form-group">
                                        <label for="postcode_zip" class="col-md-3 text-md-right col-form-label">
                                            Postcode Zip
                                        </label>
                                        <div class="col-md-9 col-xl-8">
                                            <input name="postcode_zip" id="postcode_zip"
                                                   placeholder="Postcode Zip" type="text" class="form-control"
                                                   value="<?php echo e($order->postcode_zip); ?>">
                                        </div>
                                    </div>

                                    <div class="position-relative row form-group">
                                        <label for="town_city" class="col-md-3 text-md-right col-form-label">
                                            Town City
                                        </label>
                                        <div class="col-md-9 col-xl-8">
                                            <input name="town_city" id="town_city" placeholder="Town City"
                                                   type="text" class="form-control" value="<?php echo e($order->town_city); ?>">
                                        </div>
                                    </div>

                                    <div class="position-relative row form-group">
                                        <label for="phone"
                                               class="col-md-3 text-md-right col-form-label">Phone</label>
                                        <div class="col-md-9 col-xl-8">
                                            <input required name="phone" id="phone" placeholder="Phone" type="tel"
                                                   class="form-control" value="<?php echo e($order->phone); ?>">
                                        </div>
                                    </div>

                                    <div class="position-relative row form-group">
                                        <label for="payment_type"
                                               class="col-md-3 text-md-right col-form-label">Payment Type</label>
                                        <div class="col-md-9 col-xl-8">
                                            <input required name="payment_type" id="payment_type" placeholder="	Payment Type" type="text"
                                                   class="form-control" value="<?php echo e($order->payment_type); ?>">
                                        </div>
                                    </div>

                                    <div class="position-relative row form-group">
                                        <label for="status"
                                               class="col-md-3 text-md-right col-form-label">Status</label>
                                        <div class="col-md-9 col-xl-8">
                                            <select required name="status" id="status" class="form-control">
                                                <option value="">-- Status --</option>

                                                <?php $__currentLoopData = \App\Utilities\Constant::$order_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value=<?php echo e($key); ?> <?php echo e($order->status == $key ? 'selected' : ''); ?>>
                                                        <?php echo e($value); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                    </div>



                                    <div class="position-relative row form-group mb-1">
                                        <div class="col-md-9 col-xl-8 offset-md-2">
                                            <a href="./admin/user" class="border-0 btn btn-outline-danger mr-1">
                                                    <span class="btn-icon-wrapper pr-1 opacity-8">
                                                        <i class="fa fa-times fa-w-20"></i>
                                                    </span>
                                                <span>Cancel</span>
                                            </a>

                                            <button type="submit"
                                                    class="btn-shadow btn-hover-shine btn btn-primary">
                                                    <span class="btn-icon-wrapper pr-2 opacity-8">
                                                        <i class="fa fa-download fa-w-20"></i>
                                                    </span>
                                                <span>Save</span>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/admin/order/edit.blade.php ENDPATH**/ ?>