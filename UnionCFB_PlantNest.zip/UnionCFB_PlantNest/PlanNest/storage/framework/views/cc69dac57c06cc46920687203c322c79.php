<?php $__env->startSection('title', 'Edit'); ?>

<?php $__env->startSection('content'); ?>


            <!-- Main -->
            <div class="app-main__inner">

                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-ticket icon-gradient bg-mean-fruit"></i>
                            </div>
                            <div>
                                Blogs
                                <div class="page-title-subheading">
                                    View, create, update, delete and manage.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="main-card mb-3 card">
                            <div class="card-body">
                                <form method="post" action="/admin/blogs/<?php echo e($blog -> id); ?>" enctype="multipart/form-data">

                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>

                                    <?php echo $__env->make('admin.components.notiification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    <div class="position-relative row form-group">
                                        <label for="image"
                                               class="col-md-3 text-md-right col-form-label">Image</label>
                                        <div class="col-md-9 col-xl-8">
                                            <img style="height: 200px; cursor: pointer;"
                                                 class="thumbnail " data-toggle="tooltip"
                                                 title="Click to change the image" data-placement="bottom"
                                                 <?php if($blog->image != '' || $blog->image != null): ?>
                                                     src="front/img/blog/<?php echo e($blog->image); ?>"
                                                 <?php else: ?>
                                                     src="dashboard/assets/images/add-image-icon.jpg"
                                                 <?php endif; ?> alt="Avatar">
                                            <input name="image" type="file" onchange="changeImg(this)"
                                                   class="image form-control-file" style="display: none;" value="">
                                            <input type="hidden" name="image_old" value="<?php echo e($blog->image); ?>">

                                            <small class="form-text text-muted">
                                                Click on the image to change (required)
                                            </small>
                                        </div>
                                    </div>

                                    <div class="position-relative row form-group">
                                        <label for="title" class="col-md-3 text-md-right col-form-label">Title</label>
                                        <div class="col-md-9 col-xl-8">
                                            <input required name="title" id="title" placeholder="Title" type="text"
                                                   class="form-control" value="<?php echo e($blog->title); ?>">
                                        </div>
                                    </div>



                                    <div class="position-relative row form-group">
                                        <label for="author"
                                               class="col-md-3 text-md-right col-form-label">Author</label>
                                        <div class="col-md-9 col-xl-8">
                                            <input required name="author" id="author" placeholder="Author" type="text"
                                                   class="form-control" value="<?php echo e($blog->author); ?>">
                                        </div>
                                    </div>



                                    <div class="position-relative row form-group">
                                        <label for="author_introduction"
                                               class="col-md-3 text-md-right col-form-label">Introduction</label>
                                        <div class="col-md-9 col-xl-8">
                                            <input required name="author_introduction" id="author_introduction" placeholder="Author Introduction" type="text"
                                                   class="form-control" value="<?php echo e($blog->author_introduction); ?>">
                                        </div>
                                    </div>

                                    <div class="position-relative row form-group">
                                        <label for="description"
                                               class="col-md-3 text-md-right col-form-label">Description</label>
                                        <div class="col-md-9 col-xl-8">
                                            <input required name="description" id="description" placeholder="Description" type="text"
                                                   class="form-control" value="<?php echo e($blog->description); ?>">
                                        </div>
                                    </div>

                                    <div class="position-relative row form-group">
                                        <label for="content"
                                               class="col-md-3 text-md-right col-form-label">Content</label>
                                        <div class="col-md-9 col-xl-8">
                                            <textarea class="form-control" name="content" id="content" placeholder="Content"><?php echo e($blog->content); ?></textarea>
                                        </div>
                                    </div>

                                    <div class="position-relative row form-group mb-1">
                                        <div class="col-md-9 col-xl-8 offset-md-2">
                                            <a href="./admin/blogs" class="border-0 btn btn-outline-danger mr-1">
                                                    <span class="btn-icon-wrapper pr-1 opacity-8">
                                                        <i class="fa fa-times fa-w-20"></i>
                                                    </span>
                                                <span>Cancel</span>
                                            </a>

                                            <button type="submit"
                                                    class="btn-shadow btn-hover-shine btn btn-primary">
                                                    <span class="btn-icon-wrapper pr-2 opacity-8">
                                                        <i class="fa fa-download fa-w-20"></i>
                                                    </span>
                                                <span>Save</span>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Main -->
            <script src="https://cdn.ckeditor.com/4.14.1/standard/ckeditor.js"></script>
            <script>
                CKEDITOR.replace('content');

            </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/admin/blog/edit.blade.php ENDPATH**/ ?>