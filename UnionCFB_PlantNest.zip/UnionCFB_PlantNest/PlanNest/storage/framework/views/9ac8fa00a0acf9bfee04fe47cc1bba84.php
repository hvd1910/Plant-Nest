<?php if(session('notification')): ?>
    <div class="alert alert-warning" role="alert">
        <?php echo e(session('notification')); ?>

    </div>
<?php endif; ?>


<?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/admin/components/notiification.blade.php ENDPATH**/ ?>