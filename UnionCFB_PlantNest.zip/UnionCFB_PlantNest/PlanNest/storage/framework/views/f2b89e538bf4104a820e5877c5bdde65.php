<?php $__env->startSection('title', 'Blogs Detail'); ?>
<?php $__env->startSection('content'); ?>

    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(front/img/bg-img/24.jpg);">
            <h2>SINGLE BLOG POST</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href=""><i class="fa fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item"><a href="./blogs">Blog</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Single Blog Post</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### Blog Content Area Start ##### -->
    <section class="blog-content-area section-padding-0-100">
        <div class="container">
            <div class="row justify-content-center">
                <!-- Blog Posts Area -->
                <div class="col-12 col-md-8">
                    <div class="blog-posts-area">

                        <!-- Post Details Area -->
                        <div class="single-post-details-area">
                            <div class="post-content">
                                <h4 class="post-title"><?php echo e($blog->title); ?></h4>
                                <div class="post-meta mb-30">
                                    <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i> 19 Jun 2018</a>
                                    <a href="#"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e($blog->author); ?></a>
                                </div>
                                <div class="post-thumbnail mb-30">
                                    <img src="front/img/blog/<?php echo e($blog->image); ?>" alt="">
                                </div>
                                <?php echo $blog->content; ?>

                            </div>
                        </div>




                    </div>
                </div>

                <!-- Blog Sidebar Area -->
                <div class="col-12 col-sm-9 col-md-4">
                    <div class="post-sidebar-area">


                        <!-- ##### Single Widget Area ##### -->
                        <div class="single-widget-area">
                            <!-- Author Widget -->
                            <div class="author-widget">
                                <div class="author-thumb-name d-flex align-items-center">
                                    <div class="author-thumb">
                                        <img src="front/img/bg-img/29.jpg" alt="">
                                    </div>
                                    <div class="author-name">
                                        <h5><?php echo e($blog->author); ?></h5>
                                        <p>Editor</p>
                                    </div>
                                </div>
                                <p><?php echo e($blog->author_introduction); ?></p>
                                <div class="social-info">
                                    <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                    <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                    <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                    <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>

                        <!-- ##### Single Widget Area ##### -->
                        <div class="single-widget-area">
                            <!-- Title -->
                            <div class="widget-title">
                                <h4>Recent post</h4>
                            </div>

                            <?php $__currentLoopData = $blog2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Single Latest Posts -->
                                <div class="single-latest-post d-flex align-items-center">
                                    <div class="post-thumb">
                                        <img src="front/img/blog/<?php echo e($blog1->image); ?>" alt="">
                                    </div>
                                    <div class="post-content">
                                        <a href="./blogs/<?php echo e($blog1->id); ?>" class="post-title">
                                            <h6><?php echo e($blog1->title); ?></h6>
                                        </a>
                                        <a href="#" class="post-date"><?php echo e(date('M, d, Y,', strtotime($blog->created_at))); ?></a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Blog Content Area End ##### -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/front/blog/blog_detail.blade.php ENDPATH**/ ?>