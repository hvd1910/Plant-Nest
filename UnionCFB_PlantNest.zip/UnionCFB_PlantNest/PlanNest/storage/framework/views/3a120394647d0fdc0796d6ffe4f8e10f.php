<?php $__env->startSection('title', 'Order Detail'); ?>
<?php $__env->startSection('content'); ?>

    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(front/img/bg-img/24.jpg);">
            <h2>Order Detail</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Order Detail</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### Checkout Area Start ##### -->
    <div class="checkout_area mb-100">
        <div class="container">
            <div class="row justify-content-between">
                <form action="" method="post" class="row justify-content-between">
                    <div class="col-12 col-lg-7">
                        <div class="checkout-content">
                            <a href="#" class="content-btn">
                                Order ID:
                                <b>#<?php echo e($order->id); ?></b>
                            </a>
                        </div>
                        <div class="checkout_details_area clearfix">
                            <h5>Billing Details</h5>

                            <?php echo csrf_field(); ?>
                            <div class="row">


                                <div class="col-md-6 mb-4">
                                    <label for="first_name">First Name *</label>
                                    <input disabled type="text" class="form-control" id="first_name" name="first_name" value="<?php echo e($order->first_name); ?>" required>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label for="last_name">Last Name *</label>
                                    <input disabled type="text" class="form-control" id="last_name" name="last_name" value="<?php echo e($order->last_name); ?>" required>
                                </div>
                                <div class="col-12 mb-4">
                                    <label for="email">Email Address *</label>
                                    <input disabled type="email" class="form-control" id="email" name="email" value="<?php echo e($order->email); ?>">
                                </div>
                                <div class="col-12 mb-4">
                                    <label for="phone">Phone Number *</label>
                                    <input disabled type="phone" class="form-control" id="phone" min="0" name="phone" value="<?php echo e($order->phone); ?>">
                                </div>
                                <div class="col-12 mb-4">
                                    <label for="company_name">Company Name</label>
                                    <input disabled type="text" class="form-control" id="company_name" name="company_name" value="<?php echo e($order->company_name); ?>">
                                </div>
                                <div class="col-12 mb-4">
                                    <label for="street_address">Street Address *</label>
                                    <input disabled  type="text" class="form-control" id="street_address" name="street_address" value="<?php echo e($order->street_address); ?>">
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label for="town_city">Town/City *</label>
                                    <input disabled type="text" class="form-control" id="town_city" name="town_city" value="<?php echo e($order->town_city); ?>">
                                </div>

                                <div class="col-md-6 mb-4">
                                    <label for="postcode_zip">Postcode/Zip *</label>
                                    <input disabled type="text" class="form-control" id="postcode_zip" name="postcode_zip" value="<?php echo e($order->postcode_zip); ?>">
                                </div>
                                <div class="col-12 mb-4">
                                    <label for="country">Country *</label>
                                    <input disabled type="text" class="form-control" id="country" name="country" value="<?php echo e($order->country); ?>">
                                </div>

                                <div class="col-12">
                                    <div class="d-flex align-items-center">
                                        <!-- Single Checkbox -->

                                        <!-- Single Checkbox -->

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class="col-12 col-lg-4">
                        <div class="checkout-content">
                            <h5 class="title--">Your Order</h5>
                            <div class="products">
                                <div class="products-data">
                                    <h5>Products:</h5>
                                    <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="single-products d-flex justify-content-between align-items-center">
                                        <p><?php echo e($orderDetail->product->name); ?> x <?php echo e($orderDetail->qty); ?></p>
                                        <h5>$<?php echo e($orderDetail->total); ?></h5>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>

                            <div class="order-total d-flex justify-content-between align-items-center">
                                <h5>Order Total</h5>
                                <h5>$<?php echo e(array_sum(array_column($order->orderDetails->toArray(), 'total'))); ?></h5>


                            </div>

                            <div class="payment-check">
                                <div class="pc-item">
                                    <label for="pc-check">
                                        Pay later
                                        <input type="radio" id = pc-check name="payment_type" value="pay_later" <?php echo e($order->payment_type == 'pay_later' ? 'checked' : ''); ?> disabled>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                                <div class="pc-item">
                                    <label>
                                        Online payment
                                        <input type="radio" id = pc-paypal name="payment_type" value="online_payment" <?php echo e($order->payment_type == 'online_payment' ? 'checked' : ''); ?> disabled>
                                        <span class="checkmark"></span>
                                    </label>
                                </div>
                            </div>



                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- ##### Checkout Area End ##### -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/front/account/my-order/show.blade.php ENDPATH**/ ?>