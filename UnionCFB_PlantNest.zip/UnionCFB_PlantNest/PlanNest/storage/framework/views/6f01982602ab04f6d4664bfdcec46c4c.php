<?php $__env->startSection('title', 'Blogs'); ?>
<?php $__env->startSection('content'); ?>


    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(front/img/bg-img/24.jpg);">
            <h2>BLOG DEFAULT</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="/"><i class="fa fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Blog</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### Blog Area Start ##### -->
    <section class="alazea-blog-area mb-100">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-8">
                    <div class="row">

                      <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Single Blog Post Area -->
                            <div class="col-12 col-lg-6">
                                <div class="single-blog-post mb-50">
                                    <div class="post-thumbnail mb-30">
                                        <a href="./blogs/<?php echo e($blog->id); ?>"><img src="front/img/blog/<?php echo e($blog->image); ?>" alt=""></a>
                                    </div>
                                    <div class="post-content">
                                        <a href="./blogs/<?php echo e($blog->id); ?>" class="post-title">
                                            <h5><?php echo e($blog->title); ?></h5>
                                        </a>
                                        <div class="post-meta">
                                            <a href="#"><i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e(date('M, d, Y,', strtotime($blog->created_at))); ?></a>
                                            <a href="#"><i class="fa fa-user" aria-hidden="true"></i> <?php echo e($blog->author); ?></a>
                                        </div>
                                        <p class="post-excerpt"><?php echo e($blog->description); ?></p>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                    <div class="row">
                        <div class="col-12">
                            <nav aria-label="Page navigation">
                                <?php echo e($blogs->links()); ?>

                            </nav>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-md-4">
                    <div class="post-sidebar-area">

                        <div class="single-widget-area">
                            <form action="/blogs"  class="search-form">

                                <input type="search" name="search" id="widgetsearch" placeholder="Search...">
                                <button type="submit"><i class="icon_search"></i></button>
                            </form>
                        </div>
                        <!-- ##### Single Widget Area ##### -->
                        <div class="single-widget-area">
                            <!-- Title -->
                            <div class="widget-title">
                                <h4>Recent post</h4>
                            </div>

                            <?php $__currentLoopData = $blog2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Single Latest Posts -->
                                <div class="single-latest-post d-flex align-items-center">
                                    <div class="post-thumb">
                                        <img src="front/img/blog/<?php echo e($blog1->image); ?>" alt="">
                                    </div>
                                    <div class="post-content">
                                        <a href="./blogs/<?php echo e($blog1->id); ?>" class="post-title">
                                            <h6><?php echo e($blog1->title); ?></h6>
                                        </a>
                                        <a href="#" class="post-date"><?php echo e(date('M, d, Y,', strtotime($blog1->created_at))); ?></a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </div>



                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Blog Area End ##### -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/front/blog/index.blade.php ENDPATH**/ ?>