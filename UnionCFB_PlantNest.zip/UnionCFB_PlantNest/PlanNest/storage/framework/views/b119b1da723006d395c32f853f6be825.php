<?php $__env->startSection('title', 'Result'); ?>

<?php $__env->startSection('content'); ?>


    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(front/img/bg-img/24.jpg);">
            <h2>Cart</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Cart</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->


    <!--    Section Begin-->
    <div class="checkout-section spad">
        <div class="container">
            <div class="col-lg-12">
                <h4><?php echo e($notification); ?></h4>

                <a href="./" class="primary-btn mt-5">Continue shopping</a>
            </div>
        </div>
    </div>
    <!--  Section End-->


<?php $__env->stopSection(); ?>



<?php echo $__env->make('front.layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/front/checkout/result.blade.php ENDPATH**/ ?>