<?php $__env->startSection('title', 'Cart'); ?>
<?php $__env->startSection('content'); ?>

    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(front/img/bg-img/24.jpg);">
            <h2>Cart</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Cart</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### Cart Area Start ##### -->
    <div class="cart-area section-padding-0-100 clearfix">
        <div class="container">
            <div class="row">
                <?php if(Cart::count() > 0): ?>
                    <div class="col-12">
                        <div class="cart-table clearfix">
                            <table class="table table-responsive">
                                <thead>
                                <tr>
                                    <th>Products</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>TOTAL</th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="cart_product_img">
                                            <a href="#"><img src="front/img/products/<?php echo e($cart->options->images[0]->path); ?>" alt="Product"></a>
                                            <h5><?php echo e($cart->name); ?></h5>
                                        </td>
                                        <td class="qty">
                                            <div class="quantity">
                                                <input type="number" class="qty-text" id="qty" step="1" min="1" max="99" name="quantity" value="<?php echo e($cart->qty); ?>" data-rowid="<?php echo e($cart->rowId); ?>">
                                            </div>
                                        </td>
                                        <td class="price"><span>$<?php echo e($cart->price); ?></span></td>
                                        <td class="total_price"><span>$<?php echo e(number_format($cart->price * $cart->qty,2)); ?></span></td>
                                        <td class="action"><a href="./cart/delete/<?php echo e($cart->rowId); ?>"><i class="icon_close"></i></a></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="col-12">
                        <h4>Your cart is empty.</h4>
                    </div>
                <?php endif; ?>
            </div>

            <div class="row">

                <!-- Coupon Discount -->
                <div class="col-12 col-lg-6">
                    <div class="coupon-discount mt-70">
                        <h5>COUPON DISCOUNT</h5>
                        <p>Coupons can be applied in the cart prior to checkout. Add an eligible item from the booth of the seller that created the coupon code to your cart. Click the green "Apply code" button to add the coupon to your order. The order total will update to indicate the savings specific to the coupon code entered.</p>
                        <form>
                            <input disabled type="text" name="coupon-code" placeholder="Enter your coupon code">
                            <button style="list-style: none">APPLY COUPON</button>
                        </form>
                    </div>
                </div>

                <!-- Cart Totals -->
                <div class="col-12 col-lg-6">
                    <div class="cart-totals-area mt-70">
                        <h5 class="title--">Cart Total</h5>
                        <div class="subtotal d-flex justify-content-between">
                            <h5>Subtotal</h5>
                            <h5>$<?php echo e($subtotal); ?></h5>
                        </div>

                        <div class="total d-flex justify-content-between">
                            <h5>Total</h5>
                            <h5>$<?php echo e($total); ?></h5>
                        </div>
                        <div class="checkout-btn">
                            <a href="./checkout" class="btn alazea-btn w-100">PROCEED TO CHECKOUT</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- ##### Cart Area End ##### -->

    <!-- ##### Footer Area Start ##### -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/front/shop/cart.blade.php ENDPATH**/ ?>