<?php $__env->startSection('title', 'Product Image '); ?>

<?php $__env->startSection('content'); ?>


            <!-- Main -->
            <div class="app-main__inner">

                <div class="app-page-title">
                    <div class="page-title-wrapper">
                        <div class="page-title-heading">
                            <div class="page-title-icon">
                                <i class="pe-7s-ticket icon-gradient bg-mean-fruit"></i>
                            </div>
                            <div>
                                Product Images
                                <div class="page-title-subheading">
                                    View, create, update, delete and manage.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12 image_edit">
                        <div class="main-card mb-3 card">
                            <div class="card-body">

                                <div class="position-relative row form-group">
                                    <label for="name" class="col-md-3 text-md-right col-form-label">Product Name</label>
                                    <div class="col-md-9 col-xl-8">
                                        <input disabled placeholder="Product Name" type="text"
                                               class="form-control" value="<?php echo e($product->name); ?>">
                                    </div>
                                </div>

                                <div class="position-relative row form-group">
                                    <label for="" class="col-md-3 text-md-right col-form-label">Images</label>
                                    <div class="col-md-9 col-xl-8">
                                        <ul class="text-nowrap" id="images">

                                            <?php $__currentLoopData = $productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="float-left d-inline-block mr-2 mb-2" style="position: relative; width: 32%;">
                                                    <form  action="./admin/product/<?php echo e($product->id); ?>/image/<?php echo e($productImage->id); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>

                                                        <button type="submit"
                                                                onclick="return confirm('Do you really want to delete this item?')"
                                                                class="btn btn-sm btn-outline-danger border-0 position-absolute">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </form>
                                                    <div style="width: 100%; height: 220px; overflow: hidden;">
                                                        <img  src="./front/img/products/<?php echo e($productImage->path); ?>"
                                                              alt="Image">
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <li class="float-left d-inline-block mr-2 mb-2" style="width: 32%;">
                                                <form method="post" action="admin/product/<?php echo e($product->id); ?>/image" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <div style="width: 100%; max-height: 220px; overflow: hidden;">
                                                        <img style="width: 100%; cursor: pointer;"
                                                             class="thumbnail"
                                                             data-toggle="tooltip" title="Click to add image" data-placement="bottom"
                                                             src="./dashboard/assets/images/add-image-icon.jpg" alt="Add Image">

                                                        <input name="image" type="file" onchange="changeImg(this); this.form.submit()"
                                                               accept="image/x-png,image/gif,image/jpeg"
                                                               class="image form-control-file" style="display: none;">

                                                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                                    </div>
                                                </form>
                                            </li>
                                        </ul>
                                    </div>
                                </div>

                                <div class="position-relative row form-group mb-1">
                                    <div class="col-md-9 col-xl-8 offset-md-3">
                                        <a href="./admin/product/<?php echo e($product->id); ?>" class="btn-shadow btn-hover-shine btn btn-primary">
                                                <span class="btn-icon-wrapper pr-2 opacity-8">
                                                    <i class="fa fa-check fa-w-20"></i>
                                                </span>
                                            <span>OK</span>
                                        </a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Main -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/admin/product/image/index.blade.php ENDPATH**/ ?>