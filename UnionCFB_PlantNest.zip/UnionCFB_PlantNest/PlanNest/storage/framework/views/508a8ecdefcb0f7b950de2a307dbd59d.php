<?php $__env->startSection('content'); ?>

    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(front/img/bg-img/24.jpg);">
            <h2>Checkout</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Checkout</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### Checkout Area Start ##### -->
    <div class="checkout_area mb-100">
        <div class="container">
            <div class="row justify-content-between">
                <form action="" method="post" class="row justify-content-between">
                <div class="col-12 col-lg-7">
                    <div class="checkout_details_area clearfix">
                        <h5>Billing Details</h5>

                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <input type="hidden" id="user_id" name="user_id" value="<?php echo e(Auth::user()->id ?? ''); ?>">

                                <div class="col-md-6 mb-4">
                                    <label for="first_name">First Name *</label>
                                    <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo e(Auth::user()->name ?? ''); ?>" required>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label for="last_name">Last Name *</label>
                                    <input type="text" class="form-control" id="last_name" name="last_name" value="" required>
                                </div>
                                <div class="col-12 mb-4">
                                    <label for="email">Email Address *</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e(Auth::user()->email ?? ''); ?>">
                                </div>
                                <div class="col-12 mb-4">
                                    <label for="phone">Phone Number *</label>
                                    <input type="phone" class="form-control" id="phone" min="0" name="phone" value="<?php echo e(Auth::user()->phone ?? ''); ?>">
                                </div>
                                <div class="col-12 mb-4">
                                    <label for="company_name">Company Name</label>
                                    <input type="text" class="form-control" id="company_name" name="company_name" value="<?php echo e(Auth::user()->company_name ?? ''); ?>">
                                </div>
                                <div class="col-12 mb-4">
                                    <label for="street_address">Street Address *</label>
                                    <input type="text" class="form-control" id="street_address" name="street_address" value="<?php echo e(Auth::user()->street_address ?? ''); ?>">
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label for="town_city">Town/City *</label>
                                    <input type="text" class="form-control" id="town_city" name="town_city" value="<?php echo e(Auth::user()->town_city ?? ''); ?>">
                                </div>

                                <div class="col-md-6 mb-4">
                                    <label for="postcode_zip">Postcode/Zip *</label>
                                    <input type="text" class="form-control" id="postcode_zip" name="postcode_zip" value="<?php echo e(Auth::user()->postcode_zip ?? ''); ?>">
                                </div>
                                <div class="col-12 mb-4">
                                    <label for="country">Country *</label>
                                    <input type="text" class="form-control" id="country" name="country" value="<?php echo e(Auth::user()->country ?? ''); ?>">
                                </div>

                                <div class="col-12">
                                    <div class="d-flex align-items-center">
                                        <!-- Single Checkbox -->

                                        <!-- Single Checkbox -->
                                        <div class="custom-control custom-checkbox d-flex align-items-center">
                                            <input type="checkbox" class="custom-control-input" id="customCheck2">
                                            <label class="custom-control-label" for="customCheck2">Create an account?</label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                    </div>
                </div>

                <div class="col-12 col-lg-4">
                    <div class="checkout-content">
                        <h5 class="title--">Your Order</h5>
                        <div class="products">
                            <div class="products-data">
                                <h5>Products:</h5>
                                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-products d-flex justify-content-between align-items-center">
                                    <p><?php echo e($cart->name); ?> x <?php echo e($cart->qty); ?></p>
                                    <h5>$<?php echo e($cart->price *  $cart->qty); ?></h5>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="subtotal d-flex justify-content-between align-items-center">
                            <h5>Subtotal</h5>
                            <h5>$<?php echo e($subtotal); ?></h5>
                        </div>

                        <div class="order-total d-flex justify-content-between align-items-center">
                            <h5>Order Total</h5>
                            <h5>$<?php echo e($total); ?></h5>
                        </div>

                        <div class="payment-check">
                            <div class="pc-item">
                                <label for="pc-check">
                                    Pay later
                                    <input type="radio" id = pc-check name="payment_type" value="pay_later" checked>
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            <div class="pc-item">
                                <label>
                                    Online payment
                                    <input type="radio" id = pc-paypal name="payment_type" value="online_payment">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                        </div>


                        <div class="checkout-btn mt-30">
                            <button type="submit" class="btn alazea-btn w-100">Place Order</button>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>
    </div>
    <!-- ##### Checkout Area End ##### -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.master1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PlanNest\resources\views/front/checkout/index.blade.php ENDPATH**/ ?>