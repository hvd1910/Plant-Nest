<?php

namespace App\Services\ContactUs;

use App\Services\ServiceInterface;

interface ContactUsServiceInterface extends ServiceInterface
{

}
