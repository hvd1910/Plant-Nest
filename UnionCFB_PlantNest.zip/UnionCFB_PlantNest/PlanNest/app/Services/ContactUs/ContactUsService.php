<?php

namespace App\Services\ContactUs;

use App\Reponsitories\ContactUs\ContactUsReponsitoryInterface;
use App\Services\BaseService;

class ContactUsService extends BaseService implements ContactUsServiceInterface
{
    public $reponsitory;

    public function __construct(ContactUsReponsitoryInterface $contactUsReponsitory)
    {
        $this->reponsitory = $contactUsReponsitory;
    }
}
