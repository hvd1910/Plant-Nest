<?php

namespace App\Services\User;

use App\Reponsitories\ProductCategory\ProductCategoryReponsitoryInterface;
use App\Reponsitories\User\UserReponsitoryInterface;
use App\Services\ServiceInterface;

interface UserServiceInterface extends ServiceInterface
{


}
