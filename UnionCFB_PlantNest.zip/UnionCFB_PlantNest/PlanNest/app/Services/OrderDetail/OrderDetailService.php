<?php

namespace App\Services\OrderDetail;

use App\Reponsitories\Order\OrderReponsitoryInterface;
use App\Reponsitories\OrderDetail\OrderDetailReponsitoryInterface;
use App\Services\BaseService;

class OrderDetailService extends BaseService implements OrderDetailServiceInterface
{
    public $reponsitory;
    public function __construct(OrderDetailReponsitoryInterface  $orderDetailReponsitory)
    {
        $this->reponsitory = $orderDetailReponsitory;
    }
}
