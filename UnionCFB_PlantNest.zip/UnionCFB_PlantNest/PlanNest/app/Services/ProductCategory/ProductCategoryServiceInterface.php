<?php

namespace App\Services\ProductCategory;

use App\Services\ServiceInterface;

interface ProductCategoryServiceInterface extends ServiceInterface
{

}
