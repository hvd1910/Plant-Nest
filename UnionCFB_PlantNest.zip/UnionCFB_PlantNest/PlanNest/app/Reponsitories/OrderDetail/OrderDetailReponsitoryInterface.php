<?php

namespace App\Reponsitories\OrderDetail;

use App\Reponsitories\ReponsitoryInterface;

interface OrderDetailReponsitoryInterface extends ReponsitoryInterface
{

}
