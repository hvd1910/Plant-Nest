<?php

namespace App\Reponsitories\Blog;

use App\Models\Blogs;
use App\Reponsitories\BaseReponsitory;

class BlogReponsitory extends BaseReponsitory implements BlogReponsitoryInterface
{

    public function getModel()
    {
        return Blogs::class;
    }
}
