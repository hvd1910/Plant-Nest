<?php

namespace App\Reponsitories\Blog;

use App\Reponsitories\ReponsitoryInterface;

interface BlogReponsitoryInterface extends ReponsitoryInterface
{

}
