<?php

namespace App\Reponsitories\User;

use App\Reponsitories\ReponsitoryInterface;

interface UserReponsitoryInterface extends  ReponsitoryInterface
{

}
