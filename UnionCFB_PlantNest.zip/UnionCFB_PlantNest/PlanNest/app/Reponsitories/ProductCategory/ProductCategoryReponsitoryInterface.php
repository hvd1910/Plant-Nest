<?php

namespace App\Reponsitories\ProductCategory;

use App\Reponsitories\ReponsitoryInterface;

interface ProductCategoryReponsitoryInterface extends ReponsitoryInterface
{

}
