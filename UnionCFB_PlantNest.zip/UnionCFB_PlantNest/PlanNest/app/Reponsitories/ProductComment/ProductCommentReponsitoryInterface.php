<?php

namespace App\Reponsitories\ProductComment;

use App\Reponsitories\ReponsitoryInterface;

interface ProductCommentReponsitoryInterface extends ReponsitoryInterface
{

}
