<?php

namespace App\Reponsitories\ContactUs;

use App\Http\Controllers\Controller;
use App\Models\Contactus;
use App\Reponsitories\BaseReponsitory;

class ContactUsReponsitory extends BaseReponsitory implements ContactUsReponsitoryInterface
{

    public function getModel()
    {
       return Contactus::class;
    }
}
