<?php

namespace App\Reponsitories\ContactUs;

use App\Reponsitories\ReponsitoryInterface;

interface ContactUsReponsitoryInterface extends ReponsitoryInterface
{

}
