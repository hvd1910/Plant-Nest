<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\ContactUs\ContactUsServiceInterface;
use Illuminate\Http\Request;

class ContactusController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    private $contactUsService;
    public function __construct(ContactUsServiceInterface $contactUsService)
    {
        $this->contactUsService = $contactUsService;
    }


    public function index(Request $request)
    {
        $contacts = $this->contactUsService->searchAndPaginate('yourName', $request->get('search'));
        return view('admin.contactus.index', compact('contacts'));
    }


    public function show(string $id)
    {
        $contact = $this->contactUsService->find($id);
        return view ('admin.contactus.show', compact('contact'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $this->contactUsService->delete($id);

        return redirect('./admin/contactus');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */


    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */

}
