<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\OrderDetail;
use App\Models\User;
use App\Services\Order\OrderServiceInterface;
use App\Services\OrderDetail\OrderDetailServiceInterface;
use App\Services\Product\ProductServiceInterface;
use App\Services\ProductCategory\ProductCategoryServiceInterface;
use App\Services\User\UserServiceInterface;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Services\ContactUs\ContactUsServiceInterface;
use function MongoDB\BSON\fromJSON;

class DashController extends Controller
{
    private $product;
    private $order;
    private $user;
    private $category;
    private $contactus;
    private $orderdetail;

    public function __construct(ProductServiceInterface $product,
                                OrderServiceInterface $order,
                                UserServiceInterface $user,
                                ProductCategoryServiceInterface $category,
                                ContactUsServiceInterface $contactus,
                                OrderDetailServiceInterface $orderDetailService)
    {
        $this->product = $product;
        $this->order = $order;
        $this->user = $user;
        $this->category = $category;
        $this->contactus = $contactus;
        $this->orderdetail =$orderDetailService;
    }




    public function index(){
        $user = count($this->user->all());
        $product = count($this->product->all());
        $order = count($this->order->all());
        $category = count($this->category->all());
        $contactus = count($this->contactus->all());






        $time = Carbon::now()->format('Y-m-d H:s:i');
        $times1 = Carbon::now()->subDays(0)->format('Y-m-d 00:00:00');




        //Order Chartjs
        $order_v2 = count($this->orderdetail->all()->whereBetween('created_at', [$times1, $time]));
        $orders_v2[] = $order_v2;


            for($j = 2, $i = 1; $j <=30,  $i <30; $j++,$i++) {

                $time_v2 = Carbon::now()->subDays($i)->format('Y-m-d 00:00:00');
                $time_v3 = Carbon::now()->subDays($j)->format('Y-m-d 00:00:00');
                $order_v2 = count($this->orderdetail->all()->whereBetween('created_at', [$time_v3, $time_v2]));

                $orders_v2[] = $order_v2;

            }



        $orders_v2 = implode(', ', $orders_v2);




        //Price Chartjs

        $total_v2 =  array_sum(array_column($this->orderdetail->all()->whereBetween('created_at' , [$times1, $time])->toArray(), 'total'));
        $totals_v2[] = $total_v2;

        for($z = 2, $y = 1; $z <=30,  $y <30; $z++,$y++) {

            $time_v4 = Carbon::now()->subDays($y)->format('Y-m-d 00:00:00');
            $time_v5 = Carbon::now()->subDays($z)->format('Y-m-d 00:00:00');
            $total_v21 =  array_sum(array_column(($this->orderdetail->all()->whereBetween('created_at', [$time_v5, $time_v4]))->toArray(), 'total'));


            $totals_v2[] = $total_v21;

        }



        $totals_alls = array_sum($totals_v2);
        $totals_all = implode(', ', $totals_v2);



        //Times

        for( $i = 0;  $i <30; $i++) {

            $time_v1 = Carbon::now()->subDays($i)->format('m/d');
            $times_v1[] = $time_v1;
        }
        $times_arr = implode(', ', $times_v1);



        return view('admin.dash.index', compact('user', 'product', 'order','category', 'contactus', 'orders_v2', 'totals_all' ,'times_arr', 'totals_alls'));
    }




}
