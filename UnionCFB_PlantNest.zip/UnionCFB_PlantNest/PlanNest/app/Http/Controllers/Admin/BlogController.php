<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Blog\BlogServiceInterface;
use App\Utilities\Common;
use Illuminate\Http\Request;

class BlogController extends Controller
{

    private $blogService;


    public function __construct(BlogServiceInterface $blogService)
    {
        $this->blogService = $blogService;
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $blogs = $this->blogService->searchAndPaginate('title', $request->get('search'));

        return view('admin.blog.index', compact('blogs'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.blog.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->all();

        if ($request->hasFile('image')) {
            $data['image'] = Common::uploadFile($request->file('image'), 'front/img/blog');
        }


        $product = $this->blogService->create($data);

        return redirect('admin/blogs/' . $product->id)->with('success', 'Add data successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $blog = $this->blogService->find($id);
        return view('admin.blog.show', compact('blog'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $blog = $this->blogService->find($id);

        return view('admin.blog.edit', compact('blog'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $data = $request->all();


        if(isset($data['image'])) {
            $data['image'] = Common::uploadFile($request->file('image'), 'front/img/blog');



            $file_name_old = $request->get('image_old');

            if ($file_name_old != '') {
                unlink('front/img/blog/' .$file_name_old);
            }
        }





        $this->blogService->update($data, $id);

        return redirect('admin/blogs/' .$id)->with('success', 'Update data successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $blog = $this->blogService->find($id);
        unlink('front/img/blog/' . $blog->image);

        $this->blogService->delete($id);

        return redirect('admin/blogs')->with('success', 'Delete data successfully.');
    }
}

