<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Brand\BrandServiceInterface;
use App\Services\OrderDetail\OrderDetailServiceInterface;
use App\Services\Product\ProductServiceInterface;
use App\Services\ProductCategory\ProductCategoryServiceInterface;
use Illuminate\Http\Request;

class ProductController extends Controller
{

    private $productService;

    private $productCategoryService;
    private $orderDetailService;

    public function __construct(ProductServiceInterface $productService,
                                ProductCategoryServiceInterface $productCategoryService,
                                OrderDetailServiceInterface $orderDetailService)
    {
        $this->productService = $productService;
        $this->productCategoryService = $productCategoryService;
        $this->orderDetailService =$orderDetailService;
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $products = $this->productService->searchAndPaginate('name', $request->get('search'));

        return view('admin.product.index', compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

        $productCategories = $this->productCategoryService->all();

        return view('admin.product.create', compact( 'productCategories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->all();


        $product = $this->productService->create($data);

        return redirect('admin/product/' . $product->id)->with('success', 'Add data successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $product = $this->productService->find($id);
        return view('admin.product.show', compact('product'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $product = $this->productService->find($id);

        $productCategories = $this->productCategoryService->all();

        return view('admin.product.edit', compact('product', 'productCategories'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $data = $request->all();
        $this->productService->update($data, $id);

        return redirect('admin/product/' .$id)->with('success', 'Update data successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request,string $id)
    {

        $data = $request->all();


        if(count($this->orderDetailService->all()->where('product_id', '=', $id)) > 0) {

            $this->productService->update($data, $id);
            return redirect('admin/product')->with('success', 'The product has been soft erased.');
        }
        else{

            $this->productService->delete($id);
            return redirect('admin/product')->with('success', 'Delete data successfully.');
        }



    }
}
