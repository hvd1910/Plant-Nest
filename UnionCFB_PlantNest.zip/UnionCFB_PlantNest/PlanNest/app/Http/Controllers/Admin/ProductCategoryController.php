<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Product\ProductServiceInterface;
use App\Services\ProductCategory\ProductCategoryServiceInterface;
use Illuminate\Http\Request;

class ProductCategoryController extends Controller
{
    private $productCategoryService;
    private $productService;

    public function __construct(ProductCategoryServiceInterface $productCategoryService,
                                ProductServiceInterface $productService)
    {
        $this->productCategoryService = $productCategoryService;
        $this->productService =$productService;
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $productCategories = $this->productCategoryService->searchAndPaginate('name', $request->get('search'));
        return view('admin.category.index', compact('productCategories'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.category.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $this->productCategoryService->create($data);

        return redirect('admin/category')->with('success', 'Add data successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $productCategory = $this->productCategoryService->find($id);

        return view('admin.category.edit', compact('productCategory'));
    }
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $data = $request->all();
        $this->productCategoryService->update($data, $id);

        return redirect('admin/category')->with('success', 'Update data successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {

        if(count($this->productService->all()->where('product_category_id', '=', $id)) > 0) {

            return redirect('admin/category')->with('success', 'Are being exists products of this category cannot be deleted.');
        }
        else{

            $this->productCategoryService->delete($id);
            return redirect('admin/category')->with('success', 'Delete data successfully.');
        }


    }
}
