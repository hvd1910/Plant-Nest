<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Services\ContactUs\ContactUsServiceInterface;
use App\Models\Contactus;
use Illuminate\Http\Request;

class ContactusController extends Controller
{

    private $contactUsService;
    public function __construct(ContactUsServiceInterface $contactUsService)
    {
        $this->contactUsService = $contactUsService;
    }


    public function index(){

        return view('front.contactus.index');
    }


        public function postContactus(Request $request){
            $data = $request->all();

            $this -> contactUsService->create($data);

            return back()->with('success', 'Thanks for your feedback');
        }
}
