<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Services\Blog\BlogServiceInterface;
use App\Services\Product\ProductServiceInterface;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    private $productService;

    public function __construct(ProductServiceInterface $productService)
    {
        $this->productService = $productService;


    }

    public function index() {
        $products = $this->productService->all()->where('product_category_id', '<',6)->where('status', '=',0)->take(8);

        return view('front.index', compact('products'));

    }



    public function  aboutus() {
        return view('front.static_page.about');
    }




}
