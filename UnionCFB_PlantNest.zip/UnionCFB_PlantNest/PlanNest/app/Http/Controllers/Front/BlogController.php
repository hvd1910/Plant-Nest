<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Services\Blog\BlogServiceInterface;
use Illuminate\Http\Request;

class BlogController extends Controller
{


    private $blogService;
    public function __construct(BlogServiceInterface $blogService)
    {

    $this->blogService = $blogService;

    }



    public function index(Request $request) {
        $blogs = $this->blogService->searchAndPaginate('title', $request->get('search'));

        $blog2 = $this->blogService->all()->take(4);

        return view('front.blog.index', compact('blogs', 'blog2'));

    }

    public function show($id) {
        $blog = $this->blogService->find($id);

        $blog2 = $this->blogService->all()->take(4);

        return view('front.blog.blog_detail', compact('blog2', 'blog'));

    }
}
