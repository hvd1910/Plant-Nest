<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Services\Product\ProductServiceInterface;
use App\Services\ProductCategory\ProductCategoryServiceInterface;
use App\Services\ProductComment\ProductCommentServiceInterface;
use Illuminate\Http\Request;

class ShopController extends Controller
{

    private $productService;
    private $productCommentService;
    private $productCategoryService;
    public function __construct(ProductServiceInterface $productService,
                                ProductCategoryServiceInterface $productCategoryService,
                                ProductCommentServiceInterface $productCommentService)
    {
        $this->productService = $productService;
        $this->productCategoryService = $productCategoryService;
        $this->productCommentService = $productCommentService;
    }

    public function index(Request $request) {
        $categories = $this->productCategoryService->all()->where('status', '=',0);
        $products = $this->productService->getProductOnIndex($request);

        return view('front.shop.index', compact('products', 'categories'));
    }


    public function show($id){
        $product = $this->productService->find($id);
        $products = $this->productService->all()->where('product_category_id','>=', 6);


        $relatedProducts = $products->reject(function ($product1) use ($product) {
            return $product1->id === $product->id;
        });
        $relatedProducts = $relatedProducts->where('status', '=',0)->take(4);

        return view('front.shop.shop-details', compact('product', 'relatedProducts'));
    }



    public function  category($categoryName, Request $request) {
        $categories = $this->productCategoryService->all();

        $products = $this->productService->getProductsByCategory($categoryName, $request);
        return view('front.shop.index', compact('products', 'categories'));
    }


    public function postComment(Request $request) {

        if($request->user_id == ''){
            return back()->with('notification', 'You must be login.');
        }


        $this->productCommentService->create($request->all());

        return redirect()->back()->with('success', 'Submit product review successfully.');
    }





}
