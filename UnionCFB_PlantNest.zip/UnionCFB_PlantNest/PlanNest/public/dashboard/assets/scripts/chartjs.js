var sampleChartClass;
(function ($) {

    $(document).ready(function () {
        var ctx = document.getElementById('myChart').getContext('2d');
        sampleChartClass.ChartData(ctx)

    });

    sampleChartClass = {
        ChartData:function (ctx) {

            var  times = document.getElementById('times_arr').value;
            var  orders = document.getElementById('orders_v2').value;

            let times_new = times.split(",").slice().reverse()
            let orders_new = orders.split(",").slice().reverse()



            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: times_new,
                    datasets: [{
                        label: 'Order Products',
                        data: orders_new,
                        borderWidth: 2  ,
                        borderColor: 'rgb(75, 192, 192)',
                        tension: 0.1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
    }
})(jQuery);



var sampleChartClass1;
(function ($) {

    $(document).ready(function () {

        var ctx1 = document.getElementById('mybar').getContext('2d');
        sampleChartClass1.ChartData(ctx1)

    });

    sampleChartClass1 = {
        ChartData:function (ctx1) {

            var  times = document.getElementById('times_arr').value;
            var  totals = document.getElementById('totals_v2').value;

            let times_new = times.split(",").slice().reverse();
            let totals_new = totals.split(",").slice().reverse();




            new Chart(ctx1, {
                type: 'bar',
                data: {
                    labels: times_new,
                    datasets: [{
                        label: 'Order Amount($)',
                        data: totals_new,
                        backgroundColor: [
                            'rgb(105,227,132)',

                        ],
                        borderColor: [
                            'rgb(3,157,11)',

                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
    }
})(jQuery);
